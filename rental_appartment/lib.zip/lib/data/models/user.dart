class User {
  String fullname;
  String address;
  String email;
  String password;
  bool verified;

  User({
    required this.fullname,
    required this.address,
    required this.email,
    required this.password,
    this.verified = false,
  });
}
