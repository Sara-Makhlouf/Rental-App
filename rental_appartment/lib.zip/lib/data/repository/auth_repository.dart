import '../models/user.dart';

class AuthRepository {
  final Map<String, User> _users = {
    "test@test.com": User(
      fullname: "Test User",
      address: "Demo Address",
      email: "test@test.com",
      password: "123456",
      verified: true,
    ),
  };

  Future<String> login(String email, String pass) async {
    await Future.delayed(const Duration(milliseconds: 800));
    if (!_users.containsKey(email)) return "The User not found";
    if (_users[email]!.password != pass) return "Wrong password";
    if (!_users[email]!.verified) return "Account not verified";
    return "success";
  }

  Future<String> register(
    String fullname,
    String addr,
    String email,
    String pass,
  ) async {
    await Future.delayed(const Duration(milliseconds: 900));
    if (_users.containsKey(email)) {
      return "Email already exists..Try in another email";
    }
    _users[email] = User(
      fullname: fullname,
      address: addr,
      email: email,
      password: pass,
      verified: false,
    );
    return "success";
  }

  Future<String> sendReset(String email) async {
    await Future.delayed(const Duration(milliseconds: 700));
    if (!_users.containsKey(email)) return "Email not found";
    return "success";
  }

  Future<String> verify(String email, String code) async {
    await Future.delayed(const Duration(milliseconds: 700));
    if (!_users.containsKey(email)) return "User not found";
    if (code != "123456") return "Invalid code digits";
    _users[email]!.verified = true;
    return "success";
  }
}
