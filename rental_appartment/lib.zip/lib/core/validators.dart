class Validators {
  static bool isEmail(String email) {
    return RegExp(
      r"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$",
      caseSensitive: false,
    ).hasMatch(email);
  }

  static bool isPassword(String pass) {
    return pass.length >= 6;
  }
}
