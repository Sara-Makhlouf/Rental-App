import 'package:flutter/material.dart';
import '../core/validators.dart';
import '../data/repository/auth_repository.dart';

class LoginViewModel extends ChangeNotifier {
  final repo = AuthRepository();
  bool loading = false;
  String? errorMessage;

  Future<bool> login(String email, String pass) async {
    errorMessage = null;
    if (!Validators.isEmail(email)) {
      errorMessage = 'Invalid email';
      notifyListeners();
      return false;
    }
    if (!Validators.isPassword(pass)) {
      errorMessage = 'Password must be >=6 chars';
      notifyListeners();
      return false;
    }
    loading = true;
    notifyListeners();
    final res = await repo.login(email, pass);
    loading = false;
    if (res == 'success') {
      errorMessage = null;
      notifyListeners();
      return true;
    } else {
      errorMessage = res;
      notifyListeners();
      return false;
    }
  }
}
