import 'package:flutter/material.dart';
import '../core/validators.dart';
import '../data/repository/auth_repository.dart';

class ForgotViewModel extends ChangeNotifier {
  final repo = AuthRepository();
  bool loading = false;
  String? message;

  Future<bool> send(String email) async {
    message = null;
    if (!Validators.isEmail(email)) {
      message = 'Invalid email';
      notifyListeners();
      return false;
    }
    loading = true;
    notifyListeners();
    final res = await repo.sendReset(email);
    loading = false;
    if (res == 'success') {
      message = null;
      notifyListeners();
      return true;
    } else {
      message = res;
      notifyListeners();
      return false;
    }
  }
}
