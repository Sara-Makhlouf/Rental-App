import 'package:flutter/material.dart';
import '../core/validators.dart';
import '../data/repository/auth_repository.dart';

class RegisterViewModel extends ChangeNotifier {
  final repo = AuthRepository();
  bool loading = false;
  String? message;

  Future<bool> register(
    String firstName,
    String lastName,
    String phnum,
    String pass,
  ) async {
    message = null;
    if (firstName.isEmpty || lastName.isEmpty) {
      message = 'Fill all fields';
      notifyListeners();
      return false;
    }
    if (!Validators.isEmail(phnum)) {
      message = 'Invalid email';
      notifyListeners();
      return false;
    }
    if (!Validators.isPassword(pass)) {
      message = 'Password must be >= 6';
      notifyListeners();
      return false;
    }
    loading = true;
    notifyListeners();
    final res = await repo.register(firstName, lastName, phnum, pass);
    loading = false;
    if (res == 'success') {
      message = null;
      notifyListeners();
      return true;
    } else {
      message = res;
      notifyListeners();
      return false;
    }
  }
}
