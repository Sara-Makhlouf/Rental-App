import 'package:flutter/material.dart';
import '../data/repository/auth_repository.dart';

class VerificationViewModel extends ChangeNotifier {
  final repo = AuthRepository();
  bool loading = false;
  String? message;

  Future<bool> verify(String email, String code) async {
    message = null;
    loading = true;
    notifyListeners();
    final res = await repo.verify(email, code);
    loading = false;
    if (res == 'success') {
      message = null;
      notifyListeners();
      return true;
    } else {
      message = res;
      notifyListeners();
      return false;
    }
  }
}
